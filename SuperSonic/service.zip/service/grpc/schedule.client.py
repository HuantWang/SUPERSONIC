import grpc

import schedule_pb2
import schedule_pb2_grpc


def run():
    # NOTE(gRPC Python Team): .close() is possible on a channel and should be
    # used in circumstances in which the with statement does not fit the needs
    # of the code.
    with grpc.insecure_channel('localhost:50061') as channel:
        stub = schedule_pb2_grpc.ScheduleServiceStub(channel)
        response = stub.GetTvm(
            schedule_pb2.TvmRequest(action=11))  # 这是请求的数据给服务端, 然后在读取服务端返回来的数据
        print(
            f"Client received: {response.state}  {response.reward}  {response.maxLen}"
        )

# state = "hello ", reward=3.11415, maxLen=250

if __name__ == '__main__':
    run()
