import grpc
import tvm_pb2
import tvm_pb2_grpc

# 因为 RPC 应该长时间运行，考虑到性能，还需要用到并发的库。
import time # 设置系统延时,
from concurrent import futures
_ONE_DAY_IN_SECONDS = 60 * 60 * 24 # 设置服务器运行的默认时间长度

# 按照Tvm.proto中定义的, 将类实现了
# 这里GetTvm就是Tvm.proto定义的服务端函数, 
# rpc GetTvm (TvmRequest) returns (TvmResponse){}
# GetTvm 接收到的请求是在 request 中
# Tvm.proto 中定义的 name 就是 request.name
# 接着在 GetTvm 中设计 Tvm.proto 中定义的 TvmResponse

# 其实相当于实现这个类这个函数即可
class TvmServicer(tvm_pb2_grpc.TvmServiceServicer):
	def GetTvm(self, request, context):
		print(f"Received name = {request.action}") # 客户端请求的数据
		return tvm_pb2.TvmResponse(state = "hello ", reward=3.11415, maxLen=250) # 返回的参数赋值

def myserver():
	server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))  # 设置最大连接数
	tvm_pb2_grpc.add_TvmServiceServicer_to_server(TvmServicer(), server)  #
	server.add_insecure_port('[::]:50051') # 设置所有IP地址都可以访问, 端口号为50051
	server.start() # 启动服务
	
	try:
		while True:
			time.sleep(_ONE_DAY_IN_SECONDS)# 设置服务器启动一天, 一天后自动关闭
			print("时间到了, 该结束了") 
	except KeyboardInterrupt: # 如果出现ctr+c硬中断, 直接退出
		server.stop(0)

if __name__ == "__main__":
	myserver()