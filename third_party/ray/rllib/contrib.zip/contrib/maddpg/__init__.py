from ray.rllib.contrib.maddpg.maddpg import MADDPGTrainer, DEFAULT_CONFIG

__all__ = ["MADDPGTrainer", "DEFAULT_CONFIG"]
